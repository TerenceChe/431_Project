#include <string>

void distrib(std::string input_file_path, std::string output_file_path);
